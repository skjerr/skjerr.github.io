

Exjobbet    
--------
En metod för tidsdomänsyntes
Examensarbete av Staffan Kjerrström, godkänt av Lunds tekniska högskola 1967-11-24

Som utgångspunkt för arbetet användes en given metod för tidsdomänsyntes av elektriska nät.
Referens: Vasiliu C. G. ; A Practical Method for Time-Domain Network Synthesis;
                 IEEE Trans. on Circuit Theory, Vol. 2 June 1965
                 
Examensarbetet omfattade:
    Utveckling av ett program för syntes av elektriska nät med önskat impulssvar.
    Programmering av metoden i språket Algol-60 för siffermaskinen i Lund (SMIL).
    Verifiering av programmets resultat.
    Diskussion av metoder för att realisera överföringsfunktionen.

Programmet beräknar:
    Nätets överföringsfunktion.
    Resulterande impulssvar.
    Avvikelsen från önskat impulssvar.

Uppdatering av programmet under 2019:
    Programmering av metoden i språket Algol-68.
   Verifiering av programmets resultat.

Kompilator Algol 68 Genie  Ladda ner kompilator för Win32
https://jmvdveer.home.xs4all.nl/algol68g-2.8.3.win32.zip

eller  
Execute ALGOL Online (Algol 68 Genie 2.8.4)
https://www.tutorialspoint.com/execute_algol_online.php

Installation
Ladda ner, packa upp och kopiera kompilatorn från kompilator för Win32 
till lämplig mapp, exempelvis:
C:\algol\bin\a68g-2.8.3.exe

Gå till source mappen och ändra filen start.bat så att den pekar ut platsen för kompilatorn och dess filnamn.
Command Prompten startar starta.bat vid uppstart.

Användning av IRPC
Dubbelklicka på Command Prompt i source mappen.
Kör IRPC med följande kommando:
%cc% MyProg.a68  <  Ex01.txt  >  Ex01_output

Indata finns i Ex01.txt och utdata hamnar i Ex01_output.txt

Utdata för det ursprungliga programmet år 1967 finns på sidorna 39 t.o.m 54 i Exjobbet.
Exemplen som körts 2019 ger exakt samma resultat !!







